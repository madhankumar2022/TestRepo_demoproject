if(a<b)
{
i won't do it
}
else if(a>b)
{
i can't do it
}
else if(a<=b)
{
i want to do it
}
else if(a>=b)
{
how do i do it?
}
else
{
no
}